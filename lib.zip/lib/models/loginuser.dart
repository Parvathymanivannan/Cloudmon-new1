class LoginUser {
  final String? email;
  final String? password;

  LoginUser({this.email, this.password});
}
