// import 'package:Cloudmon/screens/home/splashscreen.dart';
// import 'package:get/get_navigation/src/root/get_material_app.dart';
// import 'package:provider/provider.dart';
// import 'package:flutter/material.dart';
// import '../models/FirebaseUser.dart';
// import 'authenticate/login_1.dart';

// class Wrapper extends StatelessWidget {
//   // @override
//   // Widget build(BuildContext context) {
//   //   final user = Provider.of<FirebaseUser?>(context);

//   //   // if (user == null) {
//   //   //   return const TabviewClass();
//   //   // } else {
//   //   //   return const Splachscreen();
//   //   // }
//   //   if (user == null) {
//   //     return const SignUpScreen();
//   //   } else {
//   //     return const Splachscreen();
//   //   }
//   // }
//   @override
//   Widget build(BuildContext context) {
//     return const GetMaterialApp(
//       home: SignUpScreen(),
//     );
//   }
// }
